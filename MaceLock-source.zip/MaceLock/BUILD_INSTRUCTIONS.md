# MaceLock - Build Instructions

Blocks maces from being enchanted in anvils or enchant tables, except for
players with the permission "kephale.mace.enchant" (OPs have it by default).

## Build via GitHub Actions (easiest)
1. Create a new GitHub repo (or reuse one).
2. Upload everything in this zip, KEEPING folder structure (incl. .github/).
   - Easiest reliable way: create each file directly on GitHub using
     "Add file > Create new file" and typing the full path.
3. Go to the Actions tab, wait for the green check.
4. Open the run, scroll to Artifacts, download "MaceLock-plugin".
5. Unzip -> MaceLock-1.0.0.jar -> drop in your server's /plugins folder. Restart.

## What it does
- Non-permitted players: cannot place a mace in an enchant table, cannot get
  enchant offers for a mace, cannot produce or take an anvil result involving a mace.
- OPs / permission holders: can do all of the above (so you can make the god maces).

## Granting the bypass to non-op staff
Requires a permissions plugin (e.g. LuckPerms):
  /lp user <name> permission set kephale.mace.enchant true
